@echo off
REM Chay EHO Agent - phuc vu nut "Dong bo du lieu EHO" tren web KSNB.
REM Giu cua so nay mo trong luc dong bo. Dong cua so = tat agent.
setlocal
cd /d "%~dp0"
set "PY="
python --version >nul 2>&1 && set "PY=python"
if not defined PY ( py -3 --version >nul 2>&1 && set "PY=py -3" )
if not defined PY (
    echo Chua cai Python. Hay chay file Cai-dat-EHO-Agent.bat hoac cai Python tai https://www.python.org/downloads/
    echo ^(nho tick "Add python.exe to PATH" khi cai^)
    pause
    exit /b 1
)
%PY% -c "import selenium" 2>nul
if errorlevel 1 (
    echo Chua co thu vien selenium - dang cai...
    %PY% -m pip install selenium
)
%PY% eho_agent.py
if errorlevel 1 (
    echo.
    echo EHO Agent bi loi. Xem thong bao phia tren.
    pause
)
endlocal

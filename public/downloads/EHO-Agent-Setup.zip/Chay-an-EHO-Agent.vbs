' Chay EHO Agent AN (khong hien cua so). Duoc goi khi Windows khoi dong va khi web KSNB mo link ksnb-eho://start
Set sh = CreateObject("WScript.Shell")
dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
On Error Resume Next
sh.Run "pythonw """ & dir & "\eho_agent.py""", 0, False
If Err.Number <> 0 Then
    Err.Clear
    sh.Run "pyw -3 """ & dir & "\eho_agent.py""", 0, False
End If

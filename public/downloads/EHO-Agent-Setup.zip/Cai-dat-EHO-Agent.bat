@echo off
REM Cai dat EHO Agent cho web KSNB Long Chau: chep file vao C:\Tool EHO, cai selenium, tao shortcut ngoai Desktop, chay agent.
setlocal
set "DEST=C:\Tool EHO"
echo ============================================
echo   CAI DAT EHO AGENT - KSNB LONG CHAU
echo ============================================
echo.

set "PY="
python --version >nul 2>&1 && set "PY=python"
if not defined PY ( py -3 --version >nul 2>&1 && set "PY=py -3" )
if not defined PY (
    echo [LOI] May chua cai Python.
    echo   1. Tai Python tai: https://www.python.org/downloads/
    echo   2. Khi cai, TICK o "Add python.exe to PATH"
    echo   3. Cai xong, chay lai file nay.
    start "" https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist "C:\Program Files\Google\Chrome\Application\chrome.exe" if not exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" if not exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    echo [CANH BAO] Khong thay Google Chrome. Hay cai Chrome truoc khi dong bo.
)

if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0eho_agent.py" "%DEST%\" >nul
copy /y "%~dp0Chay-EHO-Agent.bat" "%DEST%\" >nul
if not exist "%DEST%\eho_agent.py" (
    echo [LOI] Khong chep duoc file vao %DEST%. Hay giai nen file zip ra truoc roi chay lai.
    pause
    exit /b 1
)

echo Dang cai thu vien selenium...
%PY% -m pip install selenium
if errorlevel 1 (
    echo [LOI] Cai selenium that bai. Kiem tra ket noi mang roi chay lai.
    pause
    exit /b 1
)

powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\EHO Agent.lnk'); $s.TargetPath='%DEST%\Chay-EHO-Agent.bat'; $s.WorkingDirectory='%DEST%'; $s.Save()" >nul 2>&1

echo.
echo CAI DAT XONG. Da tao shortcut "EHO Agent" ngoai Desktop (lan sau bam dup shortcut do de chay).
echo Dang chay EHO Agent - GIU cua so den do mo trong luc dong bo, roi quay lai web KSNB.
echo.
start "" "%DEST%\Chay-EHO-Agent.bat"
timeout /t 5 >nul
endlocal

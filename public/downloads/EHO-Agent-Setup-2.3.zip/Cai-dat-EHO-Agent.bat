@echo off
REM Cai dat EHO Agent cho web KSNB Long Chau: chep file vao C:\Tool EHO, cai selenium, tao shortcut ngoai Desktop, chay agent.
setlocal
set "DEST=C:\Tool EHO"
echo ============================================
echo   CAI DAT EHO AGENT - KSNB LONG CHAU
echo ============================================
echo.

set "PY="
python --version >nul 2>&1 && set "PY=python"
if not defined PY ( py -3 --version >nul 2>&1 && set "PY=py -3" )
if not defined PY (
    echo [LOI] May chua cai Python.
    echo   1. Tai Python tai: https://www.python.org/downloads/
    echo   2. Khi cai, TICK o "Add python.exe to PATH"
    echo   3. Cai xong, chay lai file nay.
    start "" https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist "C:\Program Files\Google\Chrome\Application\chrome.exe" if not exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" if not exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    echo [CANH BAO] Khong thay Google Chrome. Hay cai Chrome truoc khi dong bo.
)

if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0eho_agent.py" "%DEST%\" >nul
copy /y "%~dp0ssc_ticket.py" "%DEST%\" >nul
copy /y "%~dp0ssc_detail_template.json" "%DEST%\" >nul
copy /y "%~dp0Chay-EHO-Agent.bat" "%DEST%\" >nul
copy /y "%~dp0Chay-an-EHO-Agent.vbs" "%DEST%\" >nul
copy /y "%~dp0Go-EHO-Agent.bat" "%DEST%\" >nul
if not exist "%DEST%\eho_agent.py" (
    echo [LOI] Khong chep duoc file vao %DEST%. Hay giai nen file zip ra truoc roi chay lai.
    pause
    exit /b 1
)

echo Dang cai thu vien selenium...
%PY% -m pip install selenium
if errorlevel 1 (
    echo [LOI] Cai selenium that bai. Kiem tra ket noi mang roi chay lai.
    pause
    exit /b 1
)

REM Tat agent cu (neu dang chay) de chay lai ban moi
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }; Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'eho_agent\.py' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
ping -n 3 127.0.0.1 >nul

REM 1) Tu khoi dong CUNG WINDOWS (chay an, khong hien cua so)
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\EHO Agent.lnk'); $s.TargetPath='wscript.exe'; $s.Arguments='\"%DEST%\Chay-an-EHO-Agent.vbs\"'; $s.WorkingDirectory='%DEST%'; $s.WindowStyle=7; $s.Save()" >nul 2>&1

REM 2) Lien ket ksnb-eho:// : web KSNB bam "Dong bo du lieu EHO" la tu bat agent neu agent chua chay
reg add "HKCU\Software\Classes\ksnb-eho" /ve /d "URL:KSNB EHO Agent" /f >nul
reg add "HKCU\Software\Classes\ksnb-eho" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\ksnb-eho\shell\open\command" /ve /d "wscript.exe \"%DEST%\Chay-an-EHO-Agent.vbs\"" /f >nul

echo.
echo CAI DAT XONG. Tu nay EHO Agent TU CHAY AN cung Windows - khong can mo file nao nua.
echo Dang bat agent...
wscript.exe "%DEST%\Chay-an-EHO-Agent.vbs"
ping -n 7 127.0.0.1 >nul
for /f "tokens=2 delims==" %%V in ('findstr /b /c:"VERSION =" "%DEST%\eho_agent.py"') do echo Phien ban vua chep vao may: %%V
powershell -NoProfile -Command "try { (Invoke-WebRequest -UseBasicParsing -Headers @{Origin='https://www.ksnblongchau.com'} http://127.0.0.1:8765/ping -TimeoutSec 5).Content } catch { 'Chua thay agent - thu mo lai Chay-EHO-Agent.bat de xem loi.' }"
echo.
echo Neu dong "version" o tren KHAC phien ban vua chep: tat het cua so Python/Chrome roi chay lai file nay.
echo Quay lai web KSNB, bam "Dong bo du lieu EHO". (Muon go: chay Go-EHO-Agent.bat trong C:\Tool EHO)
pause
endlocal

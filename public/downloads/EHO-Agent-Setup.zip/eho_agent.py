# -*- coding: utf-8 -*-
"""EHO Agent (chốt 26/10) — chạy trên PC của admin, phục vụ nút "Đồng bộ dữ liệu EHO" ở Truy cập nhanh của web KSNB.

Cách hoạt động:
  1. Web KSNB (trình duyệt của admin) gọi agent qua http://127.0.0.1:8765 .
  2. /open  : mở 1 cửa sổ Chrome RIÊNG (profile riêng, giữ đăng nhập) tại https://eho.frt.vn/allshopaudit — admin TỰ đăng nhập
              (tài khoản/mật khẩu/OTP). Agent KHÔNG biết, KHÔNG lưu mật khẩu.
  3. /status: cho biết đã đăng nhập EHO chưa.
  4. /sync  : chạy ngay TRONG trang EHO đó (bằng phiên đăng nhập của admin) việc gọi API stock-taking-be/ic-portal/filter, lọc
              các phiếu "Kiểm kê All shop" - "Kho hàng thường" - "Hoàn tất", trả về cho web KSNB (web gửi tiếp lên backend).
Token EHO chỉ nằm trong trang EHO / bộ nhớ trang, không ghi ra file, không gửi đi đâu.

Từ bản 2.0 agent còn phục vụ nút "Tạo Ticket SSC" (Phân công KSNB kiểm kê): mở Chrome riêng tại SSC (profile riêng, admin tự đăng nhập)
và tạo ticket "Thông báo kiểm soát" cho các shop web KSNB đưa vào (xem ssc_ticket.py).

Chạy: python eho_agent.py   (hoặc bấm đúp Chay-EHO-Agent.bat). Cần: Python 3, selenium, Google Chrome."""
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

VERSION = "2.0"
HOST, PORT = "127.0.0.1", 8765
BASE_DIR = Path(__file__).resolve().parent
# Chạy ẩn bằng pythonw (khởi động cùng Windows / web gọi qua ksnb-eho://) thì không có cửa sổ console -> ghi log ra file
if sys.stdout is None or sys.stderr is None:
    _lf = open(BASE_DIR / "agent_run.log", "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _lf
    sys.stderr = sys.stderr or _lf
PROFILE_DIR = BASE_DIR / "chrome_profile_eho"
SSC_PROFILE_DIR = BASE_DIR / "chrome_profile_ssc"
EHO_URL = "https://eho.frt.vn/allshopaudit"

# Chỉ web KSNB (và bản dev) được gọi agent. Thêm tên miền khác: tạo file allowed_origins.txt (mỗi dòng 1 origin) cạnh file này.
ALLOWED_ORIGINS = {
    "https://www.ksnblongchau.com", "https://ksnblongchau.com",
    "http://localhost:3000", "http://127.0.0.1:3000",
}
_extra = BASE_DIR / "allowed_origins.txt"
if _extra.exists():
    ALLOWED_ORIGINS |= {ln.strip().rstrip("/") for ln in _extra.read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.startswith("#")}

_driver = None
_lock = threading.Lock()
_ssc_driver = None
_ssc_lock = threading.Lock()


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def _alive(drv):
    try:
        _ = drv.current_url
        return True
    except Exception:
        return False


def get_driver(create=True):
    """Trả về trình duyệt đang mở (hoặc mở mới nếu create=True)."""
    global _driver
    with _lock:
        if _driver is not None and not _alive(_driver):
            _driver = None
        if _driver is None and create:
            PROFILE_DIR.mkdir(exist_ok=True)
            opts = Options()
            opts.add_argument(f"--user-data-dir={PROFILE_DIR}")
            opts.add_argument("--start-maximized")
            opts.add_argument("--disable-notifications")
            opts.add_experimental_option("excludeSwitches", ["enable-automation"])
            _driver = webdriver.Chrome(options=opts)
            _driver.set_script_timeout(900)
        return _driver


def open_eho():
    drv = get_driver(create=True)
    with _lock:
        try:
            if "frt.vn" not in (drv.current_url or ""):
                drv.get(EHO_URL)
            drv.switch_to.window(drv.current_window_handle)
            drv.execute_script("window.focus();")
        except Exception as e:  # trình duyệt vừa bị đóng giữa chừng
            log(f"open_eho loi: {e}")
            raise
    return {"ok": True}


# Chạy trong trang EHO: trả {logged_in, host}
JS_STATUS = """
const t = localStorage.getItem('access_token');
let ok = false;
if (t) {
  try {
    const p = JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    ok = !p.exp || p.exp * 1000 > Date.now() + 60000;
  } catch (e) { ok = true; }
}
return {logged_in: ok, host: location.host};
"""

# Chạy trong trang EHO (execute_async_script): arguments[0]=from, [1]=to, [2]=callback
JS_SYNC = """
const done = arguments[arguments.length - 1];
const from = arguments[0], to = arguments[1];
(async () => {
  const token = localStorage.getItem('access_token');
  if (!token) return done({error: 'not_logged_in'});
  const API = 'https://apilb.frt.vn/gateway/stock-taking-be/api/ic-portal/filter';
  const norm = (s) => String(s || '').normalize('NFD').replace(/[\\u0300-\\u036f]/g, '').replace(/đ/g, 'd').toLowerCase();
  const rows = [];
  let skip = 0, total = null, fetched = 0;
  while (true) {
    let r;
    try {
      r = await fetch(API, {method: 'POST', headers: {'Content-Type': 'application/json', Authorization: 'Bearer ' + token},
        body: JSON.stringify({fromDate: from, toDate: to, keyword: '', shopCodes: null, statuses: ['2'], requestTypes: [5],
                              pagination: {skipCount: skip, maxResultCount: 1000}})});
    } catch (e) { return done({error: 'network', detail: String(e)}); }
    if (r.status === 401 || r.status === 403) return done({error: 'not_logged_in', status: r.status});
    if (!r.ok) return done({error: 'http_' + r.status});
    const j = await r.json();
    total = j.totalCount; const items = j.items || [];
    for (const x of items) {
      if (norm(x.whsName).includes('kho hang thuong') && x.lastModificationTime) {
        rows.push({code: x.code, shopCode: x.shopCode, shopName: x.shopName, whsCode: x.whsCode, whsName: x.whsName,
                   statusName: x.statusName, ngayDuyet: x.lastModificationTime, creationTime: x.creationTime,
                   fromDate: x.fromDate, toDate: x.toDate});
      }
    }
    fetched += items.length; skip += items.length;
    if (!items.length || skip >= total) break;
  }
  done({ok: true, total: total, fetched: fetched, rows: rows});
})().catch((e) => done({error: 'js', detail: String(e)}));
"""



# ---------------------------------------------------------------------------------------------------------------
# Xuất Khác - Nhập Khác EHO (chốt 26/10): kéo TOÀN BỘ dòng giao dịch Nhập khác / Xuất khác theo khoảng ngày.
# API lc-gri-app/gri-tools/search-gri chỉ trả tối đa 500 PHIẾU mỗi lần (mới nhất trước) -> chia khoảng thời gian theo ĐÔI
# đệ quy (ngày -> nửa ngày -> ... tới 1 giây; hết 1 giây vẫn đủ 500 thì chia theo Loại yêu cầu) cho tới khi cửa sổ
# KHÔNG còn chạm trần. Dòng kéo được xếp vào bộ đệm trong trang; web KSNB gọi /xknk/take lấy dần từng đợt rồi đẩy lên backend.
JS_XK_START = """
const fromStr = arguments[0], toStr = arguments[1];
const picked = (Array.isArray(arguments[2]) ? arguments[2] : []).map(Number).filter((n) => Number.isInteger(n) && n > 0);
if (window.__xk && window.__xk.running) return {error: 'dang_chay'};
const getToken = () => localStorage.getItem('access_token');
if (!getToken()) return {error: 'not_logged_in'};
const API = 'https://apilb.frt.vn/gateway/lc-gri-app/api/gri-tools/search-gri';
const MAXP = 500, WORKERS = 5;
const SOURCE_TYPES = [3, 4, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 21, 22];
const pad = (n) => String(n).padStart(2, '0');
const toSec = (ymd, h, mi, se) => { const [y, m, d] = ymd.split('-').map(Number); return Date.UTC(y, m - 1, d, h, mi, se) / 1000; };
const fmt = (sec) => { const dt = new Date(sec * 1000); return dt.getUTCFullYear() + '-' + pad(dt.getUTCMonth() + 1) + '-' + pad(dt.getUTCDate()) + 'T' + pad(dt.getUTCHours()) + ':' + pad(dt.getUTCMinutes()) + ':' + pad(dt.getUTCSeconds()); };
const start = toSec(fromStr, 0, 0, 0), end = toSec(toStr, 23, 59, 59);
if (!(end >= start)) return {error: 'khoang_thoi_gian_khong_hop_le'};
const st = window.__xk = {running: true, done: false, error: null, cancelled: false, buffer: [], queries: 0, windowsDone: 0, lines: 0, capped: 0,
                          inflight: 0, queue: [], retried: 0, startedAt: Date.now(), fromStr, toStr};
for (let t = start; t <= end; t += 86400) {
  if (picked.length) { for (const s of picked) st.queue.push({a: t, b: Math.min(t + 86399, end), src: s}); }
  else st.queue.push({a: t, b: Math.min(t + 86399, end), src: 0});
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pick = (x) => ({grI_Id: x.grI_Id, code: x.code, grI_Item_Id: x.grI_Item_Id, shopCode: x.shopCode, shopName: x.shopName,
  whsCode: x.whsCode, whsName: x.whsName, griType: x.griType, griTypeName: x.griTypeName, sku: x.sku, skuName: x.skuName,
  lotNumber: x.lotNumber, expireDate: x.expireDate, quantity: x.quantity, unitCode: x.unitCode, unitName: x.unitName, barcode: x.barcode,
  identifiedBarcode: x.identifiedBarcode, sourceType: x.sourceType, sourceTypeName: x.sourceTypeName, loaiDieuChinh: x.loaiDieuChinh,
  tenLoaiDieuChinh: x.tenLoaiDieuChinh, description: x.description, status: x.status, statusName: x.statusName, createdBy: x.createdBy,
  createdByName: x.createdByName, creationTime: x.creationTime});
async function query(w) {
  const body = {codeOrRefRequest: '', sku: null, shopCode: '', status: 0, whsCode: '', griType: 0, sourceType: w.src,
                creationTimeFrom: fmt(w.a), creationTimeTo: fmt(w.b) + '.999999', pageNumber: 1, pageSize: 5000,
                permissions: ['ESM_Permission_GRIR_Create']};
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const r = await fetch(API, {method: 'POST', headers: {'Content-Type': 'application/json', Authorization: 'Bearer ' + getToken()}, body: JSON.stringify(body)});
      if (r.status === 401 || r.status === 403) throw {fatal: 'not_logged_in'};
      if (!r.ok) throw new Error('http_' + r.status);
      return await r.json();
    } catch (e) {
      if (e && e.fatal) throw e;
      st.retried++;
      await sleep(800 * (attempt + 1));
    }
  }
  throw {fatal: 'network'};
}
async function work(w) {
  const j = await query(w); st.queries++;
  const items = j.items || [];
  const saturated = new Set(items.map((x) => x.code)).size >= MAXP;
  if (saturated && w.b > w.a) { const mid = Math.floor((w.a + w.b) / 2); st.queue.push({a: w.a, b: mid, src: w.src}, {a: mid + 1, b: w.b, src: w.src}); return; }
  if (saturated && w.src === 0) { for (const s of SOURCE_TYPES) st.queue.push({a: w.a, b: w.b, src: s}); return; }
  if (saturated) st.capped++;
  for (const x of items) { st.buffer.push(pick(x)); st.lines++; }
}
async function runner() {
  while (!st.cancelled && !st.error) {
    const w = st.queue.shift();
    if (!w) { if (st.inflight === 0) break; await sleep(150); continue; }
    st.inflight++;
    try { await work(w); st.windowsDone++; } catch (e) { st.error = (e && e.fatal) || String(e); } finally { st.inflight--; }
  }
}
window.__xkTake = (n) => {
  const x = window.__xk;
  return {rows: x.buffer.splice(0, n), running: x.running, done: x.done, error: x.error, cancelled: x.cancelled, queries: x.queries,
          windowsDone: x.windowsDone, queued: x.queue.length, inflight: x.inflight, lines: x.lines, capped: x.capped, retried: x.retried,
          buffered: x.buffer.length, elapsedSec: Math.round((Date.now() - x.startedAt) / 1000)};
};
Promise.all(Array.from({length: WORKERS}, runner)).then(() => { st.running = false; st.done = !st.error && !st.cancelled; });
return {ok: true, ngay: Math.floor((end - start) / 86400) + 1};
"""


def xk_start(from_date, to_date, source_types=None):
    drv = get_driver(create=False)
    if drv is None:
        return {"error": "no_browser"}
    with _lock:
        if "eho.frt.vn" not in (drv.current_url or ""):
            return {"error": "not_logged_in"}
        loai = [int(x) for x in (source_types or []) if str(x).isdigit()]
        log(f"Keo XKNK EHO {from_date} -> {to_date}" + (f" (loai yeu cau {loai})" if loai else " (tat ca loai yeu cau)"))
        return drv.execute_script(JS_XK_START, from_date, to_date, loai) or {"error": "empty"}


def xk_take(n):
    drv = get_driver(create=False)
    if drv is None:
        return {"error": "no_browser"}
    with _lock:
        res = drv.execute_script("return window.__xkTake ? window.__xkTake(arguments[0]) : null;", int(n))
    return res or {"error": "no_job"}


def xk_cancel():
    drv = get_driver(create=False)
    if drv is None:
        return {"ok": True}
    with _lock:
        drv.execute_script("if (window.__xk) { window.__xk.cancelled = true; } return true;")
    return {"ok": True}


def status():
    drv = get_driver(create=False)
    if drv is None:
        return {"driver": False, "logged_in": False}
    try:
        with _lock:
            url = drv.current_url or ""
            if "eho.frt.vn" not in url:
                return {"driver": True, "logged_in": False, "url_host": url.split("/")[2] if "//" in url else ""}
            res = drv.execute_script(JS_STATUS)
        return {"driver": True, "logged_in": bool(res and res.get("logged_in")), "url_host": res.get("host") if res else ""}
    except Exception as e:
        return {"driver": True, "logged_in": False, "error": str(e)[:200]}


def sync(from_date, to_date):
    drv = get_driver(create=False)
    if drv is None:
        return {"error": "no_browser"}
    with _lock:
        if "eho.frt.vn" not in (drv.current_url or ""):
            return {"error": "not_logged_in"}
        log(f"Dong bo EHO {from_date} -> {to_date}")
        res = drv.execute_async_script(JS_SYNC, from_date, to_date)
    if res and res.get("ok"):
        log(f"  tai {res.get('fetched')}/{res.get('total')} phieu Hoan tat, giu {len(res.get('rows', []))} phieu Kho hang thuong")
    else:
        log(f"  loi: {res}")
    return res or {"error": "empty"}


# ---------------------------------------------------------------------------------------------------------------
# Tạo Ticket SSC (v2.0): Chrome RIÊNG cho SSC (profile riêng, giữ đăng nhập). Việc điền form/gửi nằm ở ssc_ticket.py, chạy NỀN.
def get_ssc_driver(create=True):
    global _ssc_driver
    with _ssc_lock:
        if _ssc_driver is not None and not _alive(_ssc_driver):
            _ssc_driver = None
        if _ssc_driver is None and create:
            SSC_PROFILE_DIR.mkdir(exist_ok=True)
            opts = Options()
            opts.add_argument(f"--user-data-dir={SSC_PROFILE_DIR}")
            opts.add_argument("--start-maximized")
            opts.add_argument("--disable-notifications")
            opts.add_argument("--disable-popup-blocking")
            opts.add_argument("--ignore-certificate-errors")
            opts.add_experimental_option("excludeSwitches", ["enable-automation"])
            _ssc_driver = webdriver.Chrome(options=opts)
        return _ssc_driver


def ssc_open():
    import ssc_ticket
    if ssc_ticket.STATE.get("running"):
        return {"ok": True, "running": True}
    drv = get_ssc_driver(create=True)
    with _ssc_lock:
        try:
            if "ssc.fptshop.com.vn" not in (drv.current_url or ""):
                drv.get(ssc_ticket.SSC_URL)
            drv.switch_to.window(drv.current_window_handle)
            drv.execute_script("window.focus();")
        except Exception as e:
            log(f"ssc_open loi: {e}")
            raise
    return {"ok": True}


JS_SSC_FORM = "return !!(document.getElementById('sms-ticket-title-real') && document.getElementById('add-ticket-submit'));"


def ssc_status():
    """Đang tạo ticket thì trả trạng thái lưu sẵn (KHÔNG đụng vào trình duyệt để khỏi xen vào thao tác đang chạy)."""
    import ssc_ticket
    if ssc_ticket.STATE.get("running"):
        return {"driver": True, "logged_in": True, "running": True}
    drv = get_ssc_driver(create=False)
    if drv is None:
        return {"driver": False, "logged_in": False, "running": False}
    try:
        with _ssc_lock:
            ok, host = False, ""
            for h in list(drv.window_handles)[::-1]:
                drv.switch_to.window(h)
                host = (drv.current_url or "").split("/")[2] if "//" in (drv.current_url or "") else ""
                if "ssc.fptshop.com.vn" in host and drv.execute_script(JS_SSC_FORM):
                    ok = True
                    break
        return {"driver": True, "logged_in": ok, "running": False, "url_host": host}
    except Exception as e:
        return {"driver": True, "logged_in": False, "running": False, "error": str(e)[:200]}


def ssc_start(rows, dry_run=False):
    import ssc_ticket
    if get_ssc_driver(create=False) is None:
        return {"error": "no_browser"}
    log(f"Tao ticket SSC cho {len(rows or [])} shop" + (" (CHAY THU - khong bam Gui)" if dry_run else ""))
    return ssc_ticket.start_run(lambda: get_ssc_driver(create=False), rows, dry_run)


def close_browser():
    global _driver, _ssc_driver
    with _ssc_lock:
        if _ssc_driver is not None:
            try:
                _ssc_driver.quit()
            except Exception:
                pass
            _ssc_driver = None
    with _lock:
        if _driver is not None:
            try:
                _driver.quit()
            except Exception:
                pass
            _driver = None
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    server_version = "EhoAgent/" + VERSION

    def log_message(self, fmt, *args):  # tắt log mặc định, tự log ở trên
        pass

    def _origin_ok(self):
        origin = (self.headers.get("Origin") or "").rstrip("/")
        return origin if origin in ALLOWED_ORIGINS else None

    def _send(self, code, payload, origin=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        origin = self._origin_ok()
        if not origin:
            return self._send(403, {"error": "origin_not_allowed"})
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        origin = self._origin_ok()
        if not origin:
            return self._send(403, {"error": "origin_not_allowed"})
        try:
            if self.path.startswith("/ping"):
                return self._send(200, {"ok": True, "version": VERSION}, origin)
            if self.path.startswith("/status"):
                return self._send(200, status(), origin)
            if self.path.startswith("/ssc/status"):
                return self._send(200, ssc_status(), origin)
            if self.path.startswith("/ssc/progress"):
                import ssc_ticket
                since = 0
                if "since=" in self.path:
                    try:
                        since = max(0, int(self.path.split("since=")[1].split("&")[0]))
                    except ValueError:
                        pass
                return self._send(200, ssc_ticket.progress(since), origin)
            if self.path.startswith("/xknk/take"):
                n = 3000
                if "n=" in self.path:
                    try:
                        n = max(1, min(int(self.path.split("n=")[1].split("&")[0]), 5000))
                    except ValueError:
                        pass
                return self._send(200, xk_take(n), origin)
            return self._send(404, {"error": "not_found"}, origin)
        except Exception as e:
            return self._send(500, {"error": str(e)[:300]}, origin)

    def do_POST(self):
        origin = self._origin_ok()
        if not origin:
            return self._send(403, {"error": "origin_not_allowed"})
        try:
            if self.path.startswith("/open"):
                return self._send(200, open_eho(), origin)
            if self.path.startswith("/sync"):
                b = self._body()
                return self._send(200, sync(b.get("from_date"), b.get("to_date")), origin)
            if self.path.startswith("/ssc/open"):
                return self._send(200, ssc_open(), origin)
            if self.path.startswith("/ssc/start"):
                b = self._body()
                return self._send(200, ssc_start(b.get("rows"), bool(b.get("dry_run"))), origin)
            if self.path.startswith("/ssc/cancel"):
                import ssc_ticket
                return self._send(200, ssc_ticket.cancel_run(), origin)
            if self.path.startswith("/xknk/start"):
                b = self._body()
                return self._send(200, xk_start(b.get("from_date"), b.get("to_date"), b.get("source_types")), origin)
            if self.path.startswith("/xknk/cancel"):
                return self._send(200, xk_cancel(), origin)
            if self.path.startswith("/close"):
                return self._send(200, close_browser(), origin)
            return self._send(404, {"error": "not_found"}, origin)
        except Exception as e:
            log(f"POST {self.path} loi: {e}")
            return self._send(500, {"error": str(e)[:300]}, origin)


def main():
    try:
        srv = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        log(f"Cong {PORT} dang duoc dung - EHO Agent da chay san, khong mo them ban nua.")
        return
    log(f"EHO Agent {VERSION} dang chay tai http://{HOST}:{PORT}  (cho phep: {', '.join(sorted(ALLOWED_ORIGINS))})")
    log("Giu cua so nay mo. Vao web KSNB > Trang chu > Truy cap nhanh > 'Dong bo du lieu EHO'.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        close_browser()


if __name__ == "__main__":
    main()

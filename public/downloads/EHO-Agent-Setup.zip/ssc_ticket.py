# -*- coding: utf-8 -*-
"""Tạo ticket SSC "Thông báo kiểm soát_Long Châu" (processId=293) từ EHO Agent — nút "Tạo Ticket SSC" ở web KSNB.

Phần thao tác form SSC (chọn shop Select2, Thông báo cho, bấm Gửi, lấy link ticket) được giữ NGUYÊN từ script auto_ticket_ssc.py
đã chạy thật; khác ở chỗ: không đọc Excel/D1, danh sách shop do web KSNB đưa vào, kết quả từng shop trả về cho web để ghi lên backend.
Admin TỰ đăng nhập SSC trong cửa sổ Chrome riêng của agent — agent không biết/không lưu mật khẩu.
Mỗi shop chỉ bấm Gửi ĐÚNG MỘT LẦN (đã gửi mà chưa đọc được link -> báo "can_xac_minh", không tạo lại)."""
import json
import random
import re
import threading
import time
from datetime import datetime
from pathlib import Path

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

SSC_URL = "https://ssc.fptshop.com.vn/secure/SSC01CreateTicket.jspa?processId=293&catalogId=1&issueKeys="
DELAY_BETWEEN_TICKETS = 2
DEFAULT_TIMEOUT = 30
SELECT2_TIMEOUT = 30
BASE_DIR = Path(__file__).resolve().parent
RESULTS_FILE = BASE_DIR / "ssc_results.jsonl"  # nhật ký mọi kết quả (kể cả khi web đóng giữa chừng) — để đối chiếu/khôi phục link

# Danh sách "Thông báo cho" cố định (giữ đúng như script cũ) + username KSNB phụ trách shop
INFORM_USERS = [
    "thientm",
    "khanhhd10",
    "phatdt13",
    "hauhn2",
    "vivnt",
    "linhlt68",
    "ThinhDD4",
    "QuyenPT13",
    "HungNH36",
]


def _p(msg):
    try:
        print(time.strftime("%H:%M:%S"), msg, flush=True)
    except Exception:
        pass


def log_info(msg):
    _p(f"[SSC] {msg}")


def log_warn(msg):
    _p(f"[SSC][canh bao] {msg}")


def log_error(msg):
    _p(f"[SSC][loi] {msg}")


def safe_text(value):
    return "" if value is None else str(value).strip()


def format_excel_date(value):
    """Ngày -> DD/MM/YYYY (backend trả ISO YYYY-MM-DD; không đảo ngày/tháng)."""
    text = safe_text(value)
    if not text:
        return ""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})(?:[ T].*)?", text)
    if m:
        try:
            return datetime.strptime("-".join(m.groups()), "%Y-%m-%d").strftime("%d/%m/%Y")
        except ValueError:
            return text
    m = re.search(r"(\d{1,2})[/-](\d{1,2})[/-](\d{4})", text)
    if m:
        d, mth, y = m.groups()
        return f"{int(d):02d}/{int(mth):02d}/{y}"
    return text


def format_ssc_form_date(value):
    return format_excel_date(value)


# ---- LOCATORS (nguyên bản) ----
LOC_TITLE = (By.ID, "sms-ticket-title-real")
LOC_SHOP_HIDDEN = (By.XPATH, '//*[@name="Tên shop kiểm kê"]')
LOC_SELECT2_DROP_SEARCH = (By.CSS_SELECTOR, "#select2-drop > div > input")
LOC_DATE = (By.ID, "date--10400")
LOC_NOTE = (By.XPATH, '//*[@name="Ghi chú"]')
LOC_INFORM_TO_HIDDEN = (By.ID, "informTo")
LOC_SUBMIT = (By.ID, "add-ticket-submit")
# Link "Xem yêu cầu" xuất hiện sau khi SSC tạo ticket thành công.
# Ưu tiên locator thực tế từ giao diện SSC; bộ dò theo nội dung chữ vẫn là fallback.
LOC_VIEW_REQUEST = (By.XPATH, "/html/body/main/container/div/div/div/section/div[16]/div[2]/a[1]")


def is_invalid_session_error(err):
    text = str(err).lower()
    return (
        "invalid session id" in text
        or "session deleted" in text
        or "not connected to devtools" in text
        or "chrome not reachable" in text
        or "disconnected" in text
    )


def build_ticket_payload(item):
    shop_code = item["shop_code"]
    hinh_thuc = item["hinh_thuc"] or "Online"
    ksnb = item["ksnb"]
    # Chuẩn hóa lại tại điểm tạo payload để cả Ghi chú và trường ngày trên SSC
    # luôn nhận đúng cùng một ngày DD/MM/YYYY, bất kể nguồn là D1 hay Excel.
    ngay_kiem = format_excel_date(item["ngay_kiem"])
    ly_do_xin_kiem_ke = safe_text(item.get("ly_do_xin_kiem_ke"))

    title = f"THÔNG BÁO KIỂM SOÁT NỘI BỘ - {shop_code} (AllShop - {hinh_thuc})"

    note_lines = [
        f"KSNB kiểm kê: {ksnb}",
        f"Ngày kiểm: {ngay_kiem}",
        f"Hình thức: {hinh_thuc}",
    ]
    if ly_do_xin_kiem_ke:
        note_lines.append(f"Nội dung Xin kiểm kê: {ly_do_xin_kiem_ke}")

    note = "\n".join(note_lines)

    # Danh sách thông báo = danh sách cố định + username KSNB phụ trách shop
    # này. SSC không hiểu tên tiếng Việt (đã gặp lỗi Select2 không tìm thấy
    # kết quả khi truyền thẳng tên KSNB), và cũng KHÔNG dùng cả email — chỉ
    # cần phần trước @ (VD "quanna26@fpt.com" -> "quanna26"), đúng định dạng
    # username như danh sách INFORM_USERS cố định ở trên (thientm, vivnt...).
    inform_users = list(INFORM_USERS)

    ksnb_email = str(item.get("ksnb_email") or "").strip()
    ksnb_username = ksnb_email.split("@", 1)[0].strip() if ksnb_email else ""

    if ksnb_username:
        existing_lower = [x.lower() for x in inform_users]
        if ksnb_username.lower() not in existing_lower:
            inform_users.append(ksnb_username)
    elif ksnb:
        log_warn(f"Không tìm được email cho KSNB '{ksnb}' (shop {shop_code}) — bỏ qua Thông báo cho người này.")

    return {
        "title": title,
        "shop_code": shop_code,
        "shop_name": item["shop_name"],
        "hinh_thuc": hinh_thuc,
        "ksnb": ksnb,
        "ngay_kiem": ngay_kiem,
        "note": note,
        "inform_users": inform_users,
    }


def wait_page_ready(driver, timeout=DEFAULT_TIMEOUT):
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )


def wait_ticket_form_ready(driver, timeout=DEFAULT_TIMEOUT):
    """
    Chờ form SSC sau đăng nhập.

    Một số phiên SSC điều hướng tab sang tài nguyên giao diện (ví dụ ``en.svg``)
    sau khi đăng nhập. Khi gặp trường hợp đó, tự đưa tab về URL tạo ticket thay
    vì đứng chờ đến hết timeout trên một trang trắng.
    """
    deadline = time.time() + max(1, int(timeout))
    last_recovery = 0.0
    locators = (
        LOC_TITLE,
        LOC_SHOP_HIDDEN,
        LOC_DATE,
        LOC_NOTE,
        LOC_INFORM_TO_HIDDEN,
    )

    while time.time() < deadline:
        # Nếu SSO mở/đổi tab, ưu tiên tab nào đã có đủ form tạo ticket.
        try:
            for handle in list(driver.window_handles)[::-1]:
                driver.switch_to.window(handle)
                if all(driver.find_elements(*locator) for locator in locators):
                    log_info("Form tạo ticket đã sẵn sàng.")
                    return
        except Exception:
            pass

        try:
            current_url = str(driver.current_url or "")
        except Exception:
            current_url = ""
        current_lower = current_url.lower()

        landed_on_asset = (
            "/s-pro/assets/" in current_lower
            or current_lower.endswith((".svg", ".png", ".jpg", ".jpeg", ".webp"))
        )
        if landed_on_asset and time.time() - last_recovery >= 3:
            last_recovery = time.time()
            log_warn(
                "SSC đang hiển thị trang tài nguyên sau đăng nhập; "
                "đang mở lại đúng form tạo ticket."
            )
            try:
                driver.get(f"{SSC_URL}&_t={int(time.time())}")
            except Exception:
                pass

        time.sleep(0.5)

    try:
        final_url = driver.current_url
    except Exception:
        final_url = ""
    raise TimeoutError(
        "Quá thời gian chờ form tạo ticket SSC. "
        f"Trang hiện tại: {final_url or 'không xác định'}"
    )


def open_create_ticket_page(driver):
    driver.get("about:blank")
    time.sleep(0.5)

    fresh_url = f"{SSC_URL}&_t={int(time.time())}"
    driver.get(fresh_url)

    wait_ticket_form_ready(driver)


def scroll_to_element(driver, element):
    driver.execute_script(
        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});",
        element,
    )
    time.sleep(0.2)


def clear_and_type(element, text):
    try:
        element.clear()
    except Exception:
        pass

    element.send_keys(text)


def set_input_value_js(driver, element, value):
    driver.execute_script(
        """
        const el = arguments[0];
        const val = arguments[1];

        el.focus();
        el.value = '';
        el.dispatchEvent(new Event('input', { bubbles: true }));

        el.value = val;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        """,
        element,
        value,
    )


# =========================================================
# SELECT2 SHOP
# =========================================================

def close_select2_if_open(driver):
    try:
        ActionChains(driver).send_keys(Keys.ESCAPE).perform()
        time.sleep(0.3)
    except Exception:
        pass


def open_shop_select2(driver, timeout=DEFAULT_TIMEOUT):
    wait = WebDriverWait(driver, timeout)

    hidden = wait.until(EC.presence_of_element_located(LOC_SHOP_HIDDEN))
    scroll_to_element(driver, hidden)

    close_select2_if_open(driver)
    time.sleep(0.5)

    clicked = driver.execute_script(
        """
        const hidden = arguments[0];

        function visible(el) {
            if (!el) return false;
            const st = window.getComputedStyle(el);
            const r = el.getBoundingClientRect();

            return st.display !== 'none'
                && st.visibility !== 'hidden'
                && r.width > 0
                && r.height > 0;
        }

        function clickCenter(el) {
            if (!el) return false;

            try {
                el.scrollIntoView({block: 'center', inline: 'nearest'});

                const r = el.getBoundingClientRect();
                const x = r.left + r.width / 2;
                const y = r.top + r.height / 2;

                const target = document.elementFromPoint(x, y) || el;

                target.dispatchEvent(new MouseEvent('mouseover', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                }));

                target.dispatchEvent(new MouseEvent('mousedown', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                }));

                target.dispatchEvent(new MouseEvent('mouseup', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                }));

                target.dispatchEvent(new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                }));

                return true;
            } catch (e) {
                return false;
            }
        }

        let prev = hidden.previousElementSibling;

        if (prev && prev.classList && prev.classList.contains('select2-container')) {
            const choice = prev.querySelector(
                '.select2-choice, .select2-choices, .select2-chosen, input.select2-focusser'
            );

            if (visible(choice)) {
                return clickCenter(choice);
            }

            if (visible(prev)) {
                return clickCenter(prev);
            }
        }

        const parent = hidden.parentElement;

        if (parent) {
            const candidates = parent.querySelectorAll(
                '.select2-container, .select2-choice, .select2-choices, .select2-chosen, input.select2-focusser'
            );

            for (const c of candidates) {
                if (visible(c)) {
                    return clickCenter(c);
                }
            }
        }

        const row = hidden.closest('li');

        if (row) {
            const candidates = row.querySelectorAll(
                '.select2-container, .select2-choice, .select2-choices, .select2-chosen, input.select2-focusser'
            );

            for (const c of candidates) {
                if (visible(c)) {
                    return clickCenter(c);
                }
            }
        }

        return false;
        """,
        hidden,
    )

    if not clicked:
        raise Exception("Không click được container Select2 của field Tên shop kiểm kê.")

    possible_search_locators = [
        (By.CSS_SELECTOR, "#select2-drop > div > input"),
        (By.CSS_SELECTOR, "#select2-drop input.select2-input"),
        (By.CSS_SELECTOR, "div.select2-drop-active input.select2-input"),
        (By.CSS_SELECTOR, "input.select2-input.select2-focused"),
    ]

    last_error = None

    for locator in possible_search_locators:
        try:
            search_box = WebDriverWait(driver, 8).until(
                EC.element_to_be_clickable(locator)
            )
            log_info(f"Đã mở dropdown shop, bắt được ô search: {locator}")
            return search_box
        except Exception as e:
            last_error = e

    try:
        container = wait.until(
            EC.presence_of_element_located((
                By.XPATH,
                '//*[@name="Tên shop kiểm kê"]/preceding-sibling::div[contains(@class,"select2-container")]'
            ))
        )

        scroll_to_element(driver, container)
        ActionChains(driver).move_to_element(container).click().perform()
        time.sleep(1)

        search_box = wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#select2-drop > div > input"))
        )

        log_info("Đã mở dropdown shop bằng ActionChains.")
        return search_box

    except Exception as e:
        last_error = e

    raise Exception(f"Đã click field shop nhưng không thấy ô search Select2. Lỗi cuối: {last_error}")


def type_shop_code_to_select2(search_box, shop_code):
    try:
        search_box.clear()
    except Exception:
        pass

    for ch in str(shop_code):
        search_box.send_keys(ch)
        time.sleep(0.08)

    log_info(f"Đã nhập mã shop vào ô search Select2: {shop_code}")


def get_select2_result_texts(driver):
    results = driver.find_elements(
        By.CSS_SELECTOR,
        "#select2-drop .select2-result-label, "
        "#select2-drop li.select2-result-selectable, "
        ".select2-results .select2-result-label"
    )

    texts = []

    for r in results:
        try:
            txt = r.text.strip()
            if txt:
                texts.append(txt)
        except Exception:
            pass

    return texts


def wait_shop_result_and_click(driver, shop_code, timeout=SELECT2_TIMEOUT):
    wait = WebDriverWait(driver, timeout)
    shop_code = str(shop_code).strip()

    def find_shop_result(d):
        candidates = d.find_elements(
            By.CSS_SELECTOR,
            "#select2-drop .select2-result-label, "
            "#select2-drop li.select2-result-selectable, "
            ".select2-results .select2-result-label"
        )

        best = None

        for el in candidates:
            try:
                text = el.text.strip()
                if not text:
                    continue

                if text.startswith(shop_code):
                    return el

                if f"-{shop_code}" in text:
                    return el

                if shop_code in text and best is None:
                    best = el

            except Exception:
                continue

        return best or False

    result = wait.until(find_shop_result)

    scroll_to_element(driver, result)

    result_text = result.text.strip()

    try:
        result.click()
    except Exception:
        driver.execute_script("arguments[0].click();", result)

    log_info(f"Đã click kết quả shop: {result_text}")

    return result_text


def wait_shop_value_updated(driver, shop_code, timeout=DEFAULT_TIMEOUT):
    wait = WebDriverWait(driver, timeout)
    shop_code = str(shop_code).strip()

    hidden = wait.until(EC.presence_of_element_located(LOC_SHOP_HIDDEN))

    def value_ok(d):
        try:
            value = hidden.get_attribute("value") or ""
            text = hidden.text or ""
            blob = f"{value} {text}".lower()

            if shop_code.lower() in blob:
                return value

            return False
        except Exception:
            return False

    value = wait.until(value_ok)
    return value


def select_shop(driver, shop_code):
    shop_code = str(shop_code).strip()
    log_info(f"Đang chọn shop: {shop_code}")

    last_error = None

    for attempt in range(1, 4):
        try:
            log_info(f"Mở Select2 chọn shop lần {attempt}...")

            search_box = open_shop_select2(driver, timeout=DEFAULT_TIMEOUT)

            type_shop_code_to_select2(search_box, shop_code)

            time.sleep(1)

            result_texts = get_select2_result_texts(driver)

            if result_texts:
                log_info("Danh sách kết quả shop đang hiện:")
                for txt in result_texts[:5]:
                    _p(f"   - {txt}")
            else:
                log_warn("Chưa thấy text kết quả shop trong dropdown.")

            wait_shop_result_and_click(driver, shop_code, timeout=SELECT2_TIMEOUT)

            selected_value = wait_shop_value_updated(driver, shop_code, timeout=DEFAULT_TIMEOUT)

            log_info(f"Đã chọn shop {shop_code}. Hidden value: {selected_value}")
            return

        except Exception as e:
            last_error = e
            log_warn(f"Chọn shop lần {attempt} lỗi: {e}")

            if is_invalid_session_error(e):
                raise

            close_select2_if_open(driver)
            time.sleep(1.5)

    raise Exception(f"Không chọn được shop {shop_code}. Lỗi cuối: {last_error}")


# =========================================================
# SELECT2 USER INFORMTO
# =========================================================

def open_inform_to_select2(driver, timeout=DEFAULT_TIMEOUT):
    wait = WebDriverWait(driver, timeout)

    hidden = wait.until(EC.presence_of_element_located(LOC_INFORM_TO_HIDDEN))
    scroll_to_element(driver, hidden)

    clicked = driver.execute_script(
        """
        const hidden = arguments[0];

        function visible(el) {
            if (!el) return false;
            const st = window.getComputedStyle(el);
            const r = el.getBoundingClientRect();

            return st.display !== 'none'
                && st.visibility !== 'hidden'
                && r.width > 0
                && r.height > 0;
        }

        function clickEl(el) {
            if (!el) return false;

            try {
                el.scrollIntoView({block: 'center', inline: 'nearest'});
                el.click();
                return true;
            } catch (e) {
                return false;
            }
        }

        if (hidden.id) {
            const byId = document.getElementById('s2id_' + hidden.id);
            if (visible(byId)) {
                return clickEl(byId);
            }
        }

        let p = hidden.parentElement;

        for (let level = 0; level < 8 && p; level++) {
            const candidates = p.querySelectorAll(
                '.select2-container, .select2-choices, .select2-choice, input.select2-input'
            );

            for (const c of candidates) {
                if (visible(c)) {
                    return clickEl(c);
                }
            }

            p = p.parentElement;
        }

        return false;
        """,
        hidden,
    )

    if not clicked:
        try:
            hidden.click()
        except Exception:
            driver.execute_script("arguments[0].click();", hidden)

    possible_locators = [
        (By.CSS_SELECTOR, "#s2id_informTo input.select2-input"),
        (By.ID, "s2id_autogen20"),
        (By.CSS_SELECTOR, "input.select2-input.select2-focused"),
        (By.CSS_SELECTOR, "input.select2-input"),
    ]

    last_error = None

    for locator in possible_locators:
        try:
            return wait.until(EC.element_to_be_clickable(locator))
        except Exception as e:
            last_error = e

    raise Exception(f"Không tìm thấy ô search InformTo. Lỗi cuối: {last_error}")


def wait_user_added(driver, user, timeout=DEFAULT_TIMEOUT):
    wait = WebDriverWait(driver, timeout)
    user = str(user).strip().lower()

    hidden = wait.until(EC.presence_of_element_located(LOC_INFORM_TO_HIDDEN))

    wait.until(
        lambda d: user in ((hidden.get_attribute("value") or "").lower())
    )


def add_inform_user(driver, user):
    user = str(user).strip()

    if not user:
        return

    wait = WebDriverWait(driver, DEFAULT_TIMEOUT)
    hidden = wait.until(EC.presence_of_element_located(LOC_INFORM_TO_HIDDEN))

    current_value = hidden.get_attribute("value") or ""
    current_users = [x.strip().lower() for x in current_value.split(",") if x.strip()]

    if user.lower() in current_users:
        log_info(f"User đã có sẵn trong Thông báo cho: {user}")
        return

    log_info(f"Đang thêm Thông báo cho: {user}")

    last_error = None

    for attempt in range(1, 3):
        try:
            search_box = open_inform_to_select2(driver)

            try:
                search_box.clear()
            except Exception:
                pass

            search_box.send_keys(user)
            time.sleep(1)

            search_box.send_keys(Keys.ENTER)

            wait_user_added(driver, user)

            log_info(f"Đã thêm user: {user}")
            return

        except Exception as e:
            last_error = e
            log_warn(f"Thêm user {user} lần {attempt} lỗi: {e}")

            if is_invalid_session_error(e):
                raise

            close_select2_if_open(driver)
            time.sleep(1)

    raise Exception(f"Không thêm được user Thông báo cho: {user}. Lỗi cuối: {last_error}")


def add_inform_users(driver, users):
    if not users:
        return

    for user in users:
        add_inform_user(driver, user)


# =========================================================
# FILL FORM
# =========================================================

def fill_title(driver, title):
    wait = WebDriverWait(driver, DEFAULT_TIMEOUT)
    element = wait.until(EC.element_to_be_clickable(LOC_TITLE))
    scroll_to_element(driver, element)

    clear_and_type(element, title)

    current = element.get_attribute("value") or ""

    if title not in current:
        set_input_value_js(driver, element, title)

    log_info("Đã nhập Tiêu đề yêu cầu.")


def fill_inventory_date(driver, date_text):
    wait = WebDriverWait(driver, DEFAULT_TIMEOUT)
    element = wait.until(EC.element_to_be_clickable(LOC_DATE))
    scroll_to_element(driver, element)

    ssc_date_text = format_ssc_form_date(date_text)
    set_input_value_js(driver, element, ssc_date_text)

    current = element.get_attribute("value") or ""

    if ssc_date_text not in current:
        clear_and_type(element, ssc_date_text)

    log_info(
        f"Đã nhập Thời gian kiểm kê: {date_text} "
        f"(định dạng gửi SSC: {ssc_date_text})"
    )


def fill_note(driver, note):
    wait = WebDriverWait(driver, DEFAULT_TIMEOUT)
    element = wait.until(EC.element_to_be_clickable(LOC_NOTE))
    scroll_to_element(driver, element)

    clear_and_type(element, note)

    current = element.get_attribute("value") or ""

    if not current.strip():
        set_input_value_js(driver, element, note)

    log_info("Đã nhập Ghi chú.")


def verify_required_payload(payload):
    required = [
        ("shop_code", "Mã Shop"),
        ("title", "Tiêu đề"),
        ("ngay_kiem", "Ngày kiểm"),
        ("note", "Ghi chú"),
    ]

    missing = []

    for key, label in required:
        if not str(payload.get(key, "")).strip():
            missing.append(label)

    if missing:
        raise Exception(f"Thiếu dữ liệu bắt buộc: {', '.join(missing)}")


def fill_ticket_form(driver, payload):
    verify_required_payload(payload)

    fill_title(driver, payload["title"])
    select_shop(driver, payload["shop_code"])
    fill_inventory_date(driver, payload["ngay_kiem"])
    fill_note(driver, payload["note"])
    add_inform_users(driver, payload.get("inform_users", []))


# =========================================================
# SUBMIT + LẤY LINK TICKET THẬT
# =========================================================

class TicketSubmittedUrlMissingError(Exception):
    """SSC đã nhận thao tác Gửi nhưng automation chưa lấy được URL chi tiết."""


def find_ticket_detail_url(driver):
    """Tìm URL ticket ở tất cả tab Chrome mà không tạo lại ticket."""
    original_handle = None
    try:
        original_handle = driver.current_window_handle
    except Exception:
        pass

    try:
        handles = list(driver.window_handles)
    except Exception:
        handles = []

    for handle in handles:
        try:
            driver.switch_to.window(handle)
            current_url = str(driver.current_url or "")
            if "/s-pro/workflow/ticket/detail/" in current_url:
                return current_url
        except Exception:
            continue

    if original_handle:
        try:
            driver.switch_to.window(original_handle)
        except Exception:
            pass
    return ""


def submit_ticket(driver):
    wait = WebDriverWait(driver, DEFAULT_TIMEOUT)

    submit_btn = wait.until(EC.element_to_be_clickable(LOC_SUBMIT))
    scroll_to_element(driver, submit_btn)

    log_info("Đang bấm nút Gửi...")

    try:
        submit_btn.click()
    except Exception:
        driver.execute_script("arguments[0].click();", submit_btn)

    log_info("Đợi 5 giây để hệ thống tạo yêu cầu và hiện nút Xem yêu cầu...")
    time.sleep(5)

    # SSC có thể tải trang chi tiết rất lâu. Selenium WebElement.click() sẽ chờ
    # navigation hoàn tất và làm tiến trình trông như bị treo. Vì vậy chỉ lên lịch
    # click bằng setTimeout (để lệnh execute_script trả về trước navigation), click
    # đúng một lần, rồi chỉ theo dõi URL ở tất cả tab.
    click_info = None
    exact_error = None
    try:
        exact_link = WebDriverWait(driver, 12).until(
            EC.presence_of_element_located(LOC_VIEW_REQUEST)
        )
        click_info = driver.execute_script(
            """
            const el = arguments[0];
            const href = el.href || el.getAttribute('href') || '';
            const onclick = el.getAttribute('onclick') || '';
            el.scrollIntoView({block: 'center', inline: 'nearest'});
            window.setTimeout(() => el.click(), 0);
            return {
                clicked: true,
                source: 'xpath',
                text: (el.innerText || '').trim(),
                href: href,
                onclick: onclick,
                tag: el.tagName || ''
            };
            """,
            exact_link,
        )
    except Exception as exc:
        exact_error = exc

    if not click_info or not click_info.get("clicked"):
        if exact_error:
            log_warn(f"Không bắt được XPath Xem yêu cầu; chuyển sang dò theo nội dung: {exact_error}")
        try:
            click_info = driver.execute_script(
                """
                function isVisible(el) {
                    if (!el) return false;
                    const st = window.getComputedStyle(el);
                    const r = el.getBoundingClientRect();
                    return st.display !== 'none'
                        && st.visibility !== 'hidden'
                        && r.width > 0
                        && r.height > 0;
                }
                const candidates = Array.from(document.querySelectorAll(
                    'a, button, span, div, p, label'
                ));
                let el = candidates.find(e =>
                    isVisible(e) && (e.innerText || '').trim() === 'Xem yêu cầu'
                );
                if (!el) {
                    el = candidates.find(e =>
                        isVisible(e) && (e.innerText || '').trim().includes('Xem yêu cầu')
                    );
                }
                if (!el) {
                    return {clicked: false, reason: 'Không tìm thấy nút Xem yêu cầu'};
                }
                const clickable = el.closest('button, a, [role="button"], .btn, .cursor-pointer') || el;
                const href = clickable.href || clickable.getAttribute('href') || el.href || '';
                const onclick = clickable.getAttribute('onclick') || el.getAttribute('onclick') || '';
                clickable.scrollIntoView({block: 'center', inline: 'nearest'});
                window.setTimeout(() => clickable.click(), 0);
                return {
                    clicked: true,
                    source: 'text',
                    text: (el.innerText || '').trim(),
                    href: href,
                    onclick: onclick,
                    tag: clickable.tagName || ''
                };
                """
            )
        except Exception as exc:
            raise TicketSubmittedUrlMissingError(
                f"Ticket đã gửi nhưng phiên trình duyệt lỗi trước khi mở Xem yêu cầu: {exc}"
            )

    if not click_info or not click_info.get("clicked"):
        raise TicketSubmittedUrlMissingError(
            f"Ticket đã gửi nhưng không tìm thấy nút Xem yêu cầu: {click_info}"
        )

    href = str(click_info.get("href") or "").strip()
    log_info(
        f"Đã kích hoạt nút Xem yêu cầu đúng một lần bằng {click_info.get('source')}; "
        f"tag={click_info.get('tag')}; href={href or '(trống)'}"
    )
    if "/s-pro/workflow/ticket/detail/" in href:
        log_info(f"Ticket URL lấy trực tiếp từ nút Xem yêu cầu: {href}")
        return href

    ticket_url = ""
    last_url = ""
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            ticket_url = find_ticket_detail_url(driver)
            if ticket_url:
                break
            last_url = str(driver.current_url or "")
        except Exception as exc:
            if is_invalid_session_error(exc):
                raise TicketSubmittedUrlMissingError(
                    "Ticket đã gửi nhưng phiên ChromeDriver bị mất sau khi mở Xem yêu cầu. "
                    "Không bấm Gửi lại để tránh tạo ticket trùng."
                )
        time.sleep(0.5)

    if not ticket_url:
        raise TicketSubmittedUrlMissingError(
            f"Ticket đã gửi nhưng SSC chưa trả URL chi tiết sau 60 giây. URL cuối: {last_url or '(không đọc được)'}"
        )

    time.sleep(1)

    log_info(f"Ticket URL thật: {ticket_url}")

    return ticket_url



# =========================================================
# XỬ LÝ HÀNG LOẠT (chạy nền, web hỏi tiến độ qua /ssc/progress)
# =========================================================

def process_one_ticket(driver, payload, dry_run=False):
    open_create_ticket_page(driver)
    fill_ticket_form(driver, payload)
    if dry_run:
        return ""
    return submit_ticket(driver)


STATE = {"running": False}
_state_lock = threading.Lock()


def _append_result_file(rec):
    try:
        with open(RESULTS_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _already_created_ids():
    """Các kỳ kiểm đã bấm Gửi trước đây (có link hoặc cần xác minh) — tuyệt đối không bấm Gửi lại để khỏi trùng ticket."""
    done = set()
    try:
        for ln in RESULTS_FILE.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(ln)
            except ValueError:
                continue
            if r.get("status") in ("da_tao", "can_xac_minh"):
                done.add(int(r.get("lichlamviec_id") or 0))
    except OSError:
        pass
    return done


def start_run(driver_getter, rows, dry_run=False, extra_inform=None):
    """rows: các dòng từ backend (api_llv_ticket_jobs): id (=lichlamviec_id), ma_shop, ten_shop, hinh_thuc, ksnb, ksnb_email, ngay_kiem, notes."""
    with _state_lock:
        if STATE.get("running"):
            return {"error": "dang_chay"}
        rows = [r for r in (rows or []) if r.get("ma_shop")]
        if not rows:
            return {"error": "khong_co_shop"}
        STATE.clear()
        STATE.update({"running": True, "done": False, "cancelled": False, "dry_run": bool(dry_run), "total": len(rows), "index": 0,
                      "current": "", "created": 0, "failed": 0, "verify": 0, "skipped": 0, "results": [], "message": "Đang chuẩn bị...",
                      "started": time.time(), "error": None})
    threading.Thread(target=_run, args=(driver_getter, rows, bool(dry_run)), daemon=True).start()
    return {"ok": True, "total": len(rows)}


def cancel_run():
    if STATE.get("running"):
        STATE["cancelled"] = True
    return {"ok": True}


def progress(since=0):
    s = dict(STATE)
    res = list(s.get("results") or [])
    s["results"] = res[int(since):]
    s["next"] = len(res)
    s["elapsedSec"] = int(time.time() - s["started"]) if s.get("started") else 0
    return s


def _add_result(rec):
    rec["t"] = datetime.now().isoformat(timespec="seconds")
    STATE["results"].append(rec)
    if not STATE.get("dry_run"):
        _append_result_file(rec)


def _run(driver_getter, rows, dry_run):
    already = _already_created_ids()
    try:
        driver = driver_getter()
        STATE["message"] = "Đang mở form SSC..."
        driver.get(SSC_URL)
        wait_ticket_form_ready(driver, timeout=60)
        for i, item in enumerate(rows, start=1):
            if STATE.get("cancelled"):
                break
            lid = int(item.get("id") or item.get("lichlamviec_id") or 0)
            shop = safe_text(item.get("ma_shop"))
            STATE["index"] = i
            STATE["current"] = shop
            STATE["message"] = f"Đang {'điền thử' if dry_run else 'tạo'} ticket {i}/{len(rows)} - shop {shop}"
            if lid in already and not dry_run:
                STATE["skipped"] += 1
                _add_result({"lichlamviec_id": lid, "ma_shop": shop, "status": "bo_qua", "error_message": "Đã bấm Gửi trước đó — không tạo lại để tránh trùng"})
                continue
            try:
                payload = build_ticket_payload({
                    "shop_code": shop, "shop_name": safe_text(item.get("ten_shop")), "hinh_thuc": safe_text(item.get("hinh_thuc")),
                    "ksnb": safe_text(item.get("ksnb")), "ksnb_email": item.get("ksnb_email"), "ngay_kiem": item.get("ngay_kiem"),
                    "ly_do_xin_kiem_ke": "",
                })
                url = process_one_ticket(driver, payload, dry_run)
                if dry_run:
                    STATE["created"] += 1
                    _add_result({"lichlamviec_id": lid, "ma_shop": shop, "status": "dry_run", "payload": {k: payload[k] for k in ("title", "shop_code", "ngay_kiem", "note", "inform_users")}})
                else:
                    STATE["created"] += 1
                    _add_result({"lichlamviec_id": lid, "ma_shop": shop, "status": "da_tao", "ticket_url": url})
            except Exception as exc:  # noqa: BLE001
                msg = str(exc)[:400]
                if isinstance(exc, TicketSubmittedUrlMissingError):
                    STATE["verify"] += 1
                    _add_result({"lichlamviec_id": lid, "ma_shop": shop, "status": "can_xac_minh", "error_message": msg})
                else:
                    STATE["failed"] += 1
                    _add_result({"lichlamviec_id": lid, "ma_shop": shop, "status": "loi", "error_message": msg})
                log_warn(f"Shop {shop} lỗi: {msg}")
                if is_invalid_session_error(exc):
                    STATE["error"] = "Trình duyệt SSC bị đóng giữa chừng. Mở lại SSC rồi bấm tạo tiếp (shop đã tạo sẽ được bỏ qua)."
                    break
            time.sleep(DELAY_BETWEEN_TICKETS + random.uniform(0, 1.5))
        STATE["message"] = "Đã dừng theo yêu cầu." if STATE.get("cancelled") else "Hoàn tất."
    except Exception as exc:  # noqa: BLE001
        STATE["error"] = str(exc)[:400]
        STATE["message"] = "Lỗi: " + STATE["error"]
        log_error(STATE["error"])
    finally:
        STATE["running"] = False
        STATE["done"] = True

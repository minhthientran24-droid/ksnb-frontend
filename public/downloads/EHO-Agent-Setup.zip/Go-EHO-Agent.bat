@echo off
REM Go EHO Agent: tat agent, bo tu khoi dong cung Windows va bo lien ket ksnb-eho:// (khong xoa thu muc C:\Tool EHO).
setlocal
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }" >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\EHO Agent.lnk" >nul 2>&1
reg delete "HKCU\Software\Classes\ksnb-eho" /f >nul 2>&1
echo Da tat EHO Agent, bo tu khoi dong va bo lien ket ksnb-eho://. Muon dung lai: chay Cai-dat-EHO-Agent.bat.
pause
endlocal
